import { Component } from '@angular/core';

@Component({
  selector: 'app-wishlist-component',
  templateUrl: './wishlist-component.component.html',
  styleUrls: ['./wishlist-component.component.scss']
})
export class WishlistComponentComponent {

}
