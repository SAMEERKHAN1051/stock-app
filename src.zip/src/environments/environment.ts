export const environments = {
  production: false,
  baseUrl: 'https://finnhub.io/api/v1/',
  polyBaseUrl: 'https://api.polygon.io/v2/aggs/'
};
export const apiToken = {
  token: 'cn3tp81r01qtsta45bp0cn3tp81r01qtsta45bpg',
  polyToken: 'ctO8iVF_Gi19afBovU1ZSr6UIxqt8Fr3',
};
